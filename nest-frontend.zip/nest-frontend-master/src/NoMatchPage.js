import React from 'react';

function NoMatchPage () {
        return (
          <h3>404 - Not found</h3>
        );
}

export default NoMatchPage;