
// import React from 'react';
// import TimezonePicker from 'react-timezone-picker';
// // import {TimezonePicker} from 'baseui/timezonepicker';
 
// const [value, setValue] = React.useState(
//     "Europe/London"
//   );

//  const TimeZone = () => {
//     return (
//         <TimezonePicker
//             value={value}
//             onChange={({ id }) => setValue(id)}
//             date={new Date("2020-05-11T02:45:42.576Z")}
//         />
//     )
// }

// export default TimeZone;
