package com.douzone.nest;

// 임시용 클래스... 정식 서비스전에 제거 필요...
public class PathSetting {
//	final public static String PATH_AND_PORT = "http://localhost:3000/nest" ;
	final public static String PATH_AND_PORT = "http://192.168.0.223:8080/nest" ;
}
