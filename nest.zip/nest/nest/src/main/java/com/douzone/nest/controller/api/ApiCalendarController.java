package com.douzone.nest.controller.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.douzone.nest.dto.JsonResult;
import com.douzone.nest.service.CalendarService;
import com.douzone.nest.vo.TaskVo;
import com.douzone.nest.vo.UserProjectVo;

@CrossOrigin(origins = {"http://localhost:3000"})
@RestController
public class ApiCalendarController {
	
	@Autowired
	private CalendarService calendarService;
	
	private final SimpMessagingTemplate template;
	
	@Autowired
	public ApiCalendarController(SimpMessagingTemplate template) {
		this.template = template;
	}
	
	/* 
	 * 작성자:김우경
	 * 설명:해당하는 회원의 프로젝트와 업무가져오기
	 */
	@GetMapping("api/calendar/alltask/{authUserNo}")
	public JsonResult allTasks(@PathVariable("authUserNo") Long userNo) {
		List<UserProjectVo> userProjectNo = calendarService.selectProjectNo(userNo);

		JSONObject allProjects = calendarService.selectAllTasks(userProjectNo, userNo);
		return JsonResult.success(allProjects);
//		return null;
	}
	
	/* 
	 * 작성자:김우경
	 * 설명:모든 프로젝트의 멤버
	 */
	@GetMapping("api/calendar/allProjectMembers/{authUserNo}")
	public JsonResult allProjectMembers(@PathVariable("authUserNo") Long userNo) {
		List<UserProjectVo> userProjectNo = calendarService.selectProjectNo(userNo);

		JSONObject allProjectMembers = calendarService.selectAllProjectMembers(userProjectNo, userNo);
		return JsonResult.success(allProjectMembers);
//		return null;
	}
	
	@GetMapping("api/calendar/{authUserNo}")
	public JsonResult calendar(@PathVariable("authUserNo") Long authUserNo) {
		JSONObject taskVo = calendarService.selectTask(authUserNo);
		return JsonResult.success(taskVo);
	}
	
	@PostMapping("api/calendar/{projectNo}")
	public JsonResult taskList(@PathVariable("projectNo") Long projectNo) {
		JSONObject taskListVo = calendarService.selectTaskList(projectNo);
		return JsonResult.success(taskListVo);
	}
	
	@PostMapping("api/calendar/taskadd")
	public JsonResult taskAdd(@RequestBody TaskVo taskVo) {
		boolean result = calendarService.taskAdd(taskVo);
		return JsonResult.success(result ? taskVo : -1);
	}
	
	@MessageMapping("/calendar/all") // react -> spring 송신
//	@SendTo("/topic/all")	// spring -> react 송신
	@SuppressWarnings("unchecked")
	public void send(Map<Object, Object> socketData) {
		List memberList = (List) socketData.get("members");
		for(int i=0; i < memberList.size();i++) {
			HashMap<String, Object> member = (HashMap<String, Object>) memberList.get(i);
	        template.convertAndSend("/topic/calendar/all/"+member.get("userNo"), socketData);
		}
	}

}
